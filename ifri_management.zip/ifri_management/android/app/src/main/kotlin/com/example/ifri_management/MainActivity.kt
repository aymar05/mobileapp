package com.example.ifri_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
